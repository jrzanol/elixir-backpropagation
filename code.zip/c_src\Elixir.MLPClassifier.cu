#include "erl_nif.h"


__device__
float sigmoid(float x)
{
return ((1.0 / (1.0 + exp((- x)))));
}

__device__ void* sigmoid_ptr = (void*) sigmoid;

extern "C" void* get_sigmoid_ptr()
{
	void* host_function_ptr;
	cudaMemcpyFromSymbol(&host_function_ptr, sigmoid_ptr, sizeof(void*));
	return host_function_ptr;
}



__device__
float relu(float x)
{
	float zero = (x - x);
	float result = zero;
if((x > zero))
{
	result = x;
}

return (result);
}

__device__ void* relu_ptr = (void*) relu;

extern "C" void* get_relu_ptr()
{
	void* host_function_ptr;
	cudaMemcpyFromSymbol(&host_function_ptr, relu_ptr, sizeof(void*));
	return host_function_ptr;
}



__global__
void forward_relu_kernel(float *weights, float *input, float *biases, float *output, int prev_size, int curr_size)
{
	int j = ((blockIdx.x * blockDim.x) + threadIdx.x);
if((j < curr_size))
{
	float net = biases[j];
for( int i = 0; i<prev_size; i+=1){
	net = (net + (weights[((i * curr_size) + j)] * input[i]));
}

	output[j] = relu(net);
}

}

extern "C" void forward_relu_kernel_call(ErlNifEnv *env, const ERL_NIF_TERM argv[], ErlNifResourceType* type,ErlNifResourceType* ftype)
  {

    ERL_NIF_TERM list;
    ERL_NIF_TERM head;
    ERL_NIF_TERM tail;

   // void **fun_res;

    const ERL_NIF_TERM *tuple_blocks;
    const ERL_NIF_TERM *tuple_threads;
    int arity;

    if (!enif_get_tuple(env, argv[1], &arity, &tuple_blocks)) {
      printf ("spawn: blocks argument is not a tuple");
    }

    if (!enif_get_tuple(env, argv[2], &arity, &tuple_threads)) {
      printf ("spawn:threads argument is not a tuple");
    }
    int b1,b2,b3,t1,t2,t3;

    enif_get_int(env,tuple_blocks[0],&b1);
    enif_get_int(env,tuple_blocks[1],&b2);
    enif_get_int(env,tuple_blocks[2],&b3);
    enif_get_int(env,tuple_threads[0],&t1);
    enif_get_int(env,tuple_threads[1],&t2);
    enif_get_int(env,tuple_threads[2],&t3);

    dim3 blocks(b1,b2,b3);
    dim3 threads(t1,t2,t3);

    list= argv[3];

  float **array_res1;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res1);
    float *arg1 = *array_res1;
    list = tail;

    float **array_res2;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res2);
    float *arg2 = *array_res2;
    list = tail;

    float **array_res3;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res3);
    float *arg3 = *array_res3;
    list = tail;

    float **array_res4;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res4);
    float *arg4 = *array_res4;
    list = tail;

    enif_get_list_cell(env,list,&head,&tail);
  int arg5;
  enif_get_int(env, head, &arg5);
  list = tail;

  enif_get_list_cell(env,list,&head,&tail);
  int arg6;
  enif_get_int(env, head, &arg6);
  list = tail;

   forward_relu_kernel<<<blocks, threads>>>(arg1,arg2,arg3,arg4,arg5,arg6);
    cudaError_t error_gpu = cudaGetLastError();
    if(error_gpu != cudaSuccess)
     { char message[200];
       strcpy(message,"Error kernel call: ");
       strcat(message, cudaGetErrorString(error_gpu));
       enif_raise_exception(env,enif_make_string(env, message, ERL_NIF_LATIN1));
     }
}

__global__
void forward_sigmoid_kernel(float *weights, float *input, float *biases, float *output, int prev_size, int curr_size)
{
	int j = ((blockIdx.x * blockDim.x) + threadIdx.x);
if((j < curr_size))
{
	float net = biases[j];
for( int i = 0; i<prev_size; i+=1){
	net = (net + (weights[((i * curr_size) + j)] * input[i]));
}

	output[j] = sigmoid(net);
}

}

extern "C" void forward_sigmoid_kernel_call(ErlNifEnv *env, const ERL_NIF_TERM argv[], ErlNifResourceType* type,ErlNifResourceType* ftype)
  {

    ERL_NIF_TERM list;
    ERL_NIF_TERM head;
    ERL_NIF_TERM tail;

   // void **fun_res;

    const ERL_NIF_TERM *tuple_blocks;
    const ERL_NIF_TERM *tuple_threads;
    int arity;

    if (!enif_get_tuple(env, argv[1], &arity, &tuple_blocks)) {
      printf ("spawn: blocks argument is not a tuple");
    }

    if (!enif_get_tuple(env, argv[2], &arity, &tuple_threads)) {
      printf ("spawn:threads argument is not a tuple");
    }
    int b1,b2,b3,t1,t2,t3;

    enif_get_int(env,tuple_blocks[0],&b1);
    enif_get_int(env,tuple_blocks[1],&b2);
    enif_get_int(env,tuple_blocks[2],&b3);
    enif_get_int(env,tuple_threads[0],&t1);
    enif_get_int(env,tuple_threads[1],&t2);
    enif_get_int(env,tuple_threads[2],&t3);

    dim3 blocks(b1,b2,b3);
    dim3 threads(t1,t2,t3);

    list= argv[3];

  float **array_res1;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res1);
    float *arg1 = *array_res1;
    list = tail;

    float **array_res2;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res2);
    float *arg2 = *array_res2;
    list = tail;

    float **array_res3;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res3);
    float *arg3 = *array_res3;
    list = tail;

    float **array_res4;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res4);
    float *arg4 = *array_res4;
    list = tail;

    enif_get_list_cell(env,list,&head,&tail);
  int arg5;
  enif_get_int(env, head, &arg5);
  list = tail;

  enif_get_list_cell(env,list,&head,&tail);
  int arg6;
  enif_get_int(env, head, &arg6);
  list = tail;

   forward_sigmoid_kernel<<<blocks, threads>>>(arg1,arg2,arg3,arg4,arg5,arg6);
    cudaError_t error_gpu = cudaGetLastError();
    if(error_gpu != cudaSuccess)
     { char message[200];
       strcpy(message,"Error kernel call: ");
       strcat(message, cudaGetErrorString(error_gpu));
       enif_raise_exception(env,enif_make_string(env, message, ERL_NIF_LATIN1));
     }
}

__global__
void output_delta_kernel(float *yhat, float *y, float *delta, int size)
{
	int j = ((blockIdx.x * blockDim.x) + threadIdx.x);
if((j < size))
{
	delta[j] = (yhat[j] - y[j]);
}

}

extern "C" void output_delta_kernel_call(ErlNifEnv *env, const ERL_NIF_TERM argv[], ErlNifResourceType* type,ErlNifResourceType* ftype)
  {

    ERL_NIF_TERM list;
    ERL_NIF_TERM head;
    ERL_NIF_TERM tail;

   // void **fun_res;

    const ERL_NIF_TERM *tuple_blocks;
    const ERL_NIF_TERM *tuple_threads;
    int arity;

    if (!enif_get_tuple(env, argv[1], &arity, &tuple_blocks)) {
      printf ("spawn: blocks argument is not a tuple");
    }

    if (!enif_get_tuple(env, argv[2], &arity, &tuple_threads)) {
      printf ("spawn:threads argument is not a tuple");
    }
    int b1,b2,b3,t1,t2,t3;

    enif_get_int(env,tuple_blocks[0],&b1);
    enif_get_int(env,tuple_blocks[1],&b2);
    enif_get_int(env,tuple_blocks[2],&b3);
    enif_get_int(env,tuple_threads[0],&t1);
    enif_get_int(env,tuple_threads[1],&t2);
    enif_get_int(env,tuple_threads[2],&t3);

    dim3 blocks(b1,b2,b3);
    dim3 threads(t1,t2,t3);

    list= argv[3];

  float **array_res1;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res1);
    float *arg1 = *array_res1;
    list = tail;

    float **array_res2;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res2);
    float *arg2 = *array_res2;
    list = tail;

    float **array_res3;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res3);
    float *arg3 = *array_res3;
    list = tail;

    enif_get_list_cell(env,list,&head,&tail);
  int arg4;
  enif_get_int(env, head, &arg4);
  list = tail;

   output_delta_kernel<<<blocks, threads>>>(arg1,arg2,arg3,arg4);
    cudaError_t error_gpu = cudaGetLastError();
    if(error_gpu != cudaSuccess)
     { char message[200];
       strcpy(message,"Error kernel call: ");
       strcat(message, cudaGetErrorString(error_gpu));
       enif_raise_exception(env,enif_make_string(env, message, ERL_NIF_LATIN1));
     }
}

__global__
void output_delta_scalar_kernel(float *yhat, float y, float *delta, int size)
{
	int j = ((blockIdx.x * blockDim.x) + threadIdx.x);
if((j < size))
{
	delta[j] = (yhat[j] - y);
}

}

extern "C" void output_delta_scalar_kernel_call(ErlNifEnv *env, const ERL_NIF_TERM argv[], ErlNifResourceType* type,ErlNifResourceType* ftype)
  {

    ERL_NIF_TERM list;
    ERL_NIF_TERM head;
    ERL_NIF_TERM tail;

   // void **fun_res;

    const ERL_NIF_TERM *tuple_blocks;
    const ERL_NIF_TERM *tuple_threads;
    int arity;

    if (!enif_get_tuple(env, argv[1], &arity, &tuple_blocks)) {
      printf ("spawn: blocks argument is not a tuple");
    }

    if (!enif_get_tuple(env, argv[2], &arity, &tuple_threads)) {
      printf ("spawn:threads argument is not a tuple");
    }
    int b1,b2,b3,t1,t2,t3;

    enif_get_int(env,tuple_blocks[0],&b1);
    enif_get_int(env,tuple_blocks[1],&b2);
    enif_get_int(env,tuple_blocks[2],&b3);
    enif_get_int(env,tuple_threads[0],&t1);
    enif_get_int(env,tuple_threads[1],&t2);
    enif_get_int(env,tuple_threads[2],&t3);

    dim3 blocks(b1,b2,b3);
    dim3 threads(t1,t2,t3);

    list= argv[3];

  float **array_res1;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res1);
    float *arg1 = *array_res1;
    list = tail;

    enif_get_list_cell(env,list,&head,&tail);
  double darg2;
  float arg2;
  enif_get_double(env, head, &darg2);
  arg2 = (float) darg2;
  list = tail;

  float **array_res3;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res3);
    float *arg3 = *array_res3;
    list = tail;

    enif_get_list_cell(env,list,&head,&tail);
  int arg4;
  enif_get_int(env, head, &arg4);
  list = tail;

   output_delta_scalar_kernel<<<blocks, threads>>>(arg1,arg2,arg3,arg4);
    cudaError_t error_gpu = cudaGetLastError();
    if(error_gpu != cudaSuccess)
     { char message[200];
       strcpy(message,"Error kernel call: ");
       strcat(message, cudaGetErrorString(error_gpu));
       enif_raise_exception(env,enif_make_string(env, message, ERL_NIF_LATIN1));
     }
}

__global__
void hidden_delta_kernel(float *weights_next, float *delta_next, float *act_curr, float *delta_curr, int curr_size, int next_size)
{
	int j = ((blockIdx.x * blockDim.x) + threadIdx.x);
if((j < curr_size))
{
	int sum = 0;
for( int k = 0; k<next_size; k+=1){
	sum = (sum + (weights_next[((j * next_size) + k)] * delta_next[k]));
}

	float a = act_curr[j];
	float zero = (a - a);
if((a > zero))
{
	delta_curr[j] = sum;
}
else{
	delta_curr[j] = 0;
}

}

}

extern "C" void hidden_delta_kernel_call(ErlNifEnv *env, const ERL_NIF_TERM argv[], ErlNifResourceType* type,ErlNifResourceType* ftype)
  {

    ERL_NIF_TERM list;
    ERL_NIF_TERM head;
    ERL_NIF_TERM tail;

   // void **fun_res;

    const ERL_NIF_TERM *tuple_blocks;
    const ERL_NIF_TERM *tuple_threads;
    int arity;

    if (!enif_get_tuple(env, argv[1], &arity, &tuple_blocks)) {
      printf ("spawn: blocks argument is not a tuple");
    }

    if (!enif_get_tuple(env, argv[2], &arity, &tuple_threads)) {
      printf ("spawn:threads argument is not a tuple");
    }
    int b1,b2,b3,t1,t2,t3;

    enif_get_int(env,tuple_blocks[0],&b1);
    enif_get_int(env,tuple_blocks[1],&b2);
    enif_get_int(env,tuple_blocks[2],&b3);
    enif_get_int(env,tuple_threads[0],&t1);
    enif_get_int(env,tuple_threads[1],&t2);
    enif_get_int(env,tuple_threads[2],&t3);

    dim3 blocks(b1,b2,b3);
    dim3 threads(t1,t2,t3);

    list= argv[3];

  float **array_res1;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res1);
    float *arg1 = *array_res1;
    list = tail;

    float **array_res2;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res2);
    float *arg2 = *array_res2;
    list = tail;

    float **array_res3;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res3);
    float *arg3 = *array_res3;
    list = tail;

    float **array_res4;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res4);
    float *arg4 = *array_res4;
    list = tail;

    enif_get_list_cell(env,list,&head,&tail);
  int arg5;
  enif_get_int(env, head, &arg5);
  list = tail;

  enif_get_list_cell(env,list,&head,&tail);
  int arg6;
  enif_get_int(env, head, &arg6);
  list = tail;

   hidden_delta_kernel<<<blocks, threads>>>(arg1,arg2,arg3,arg4,arg5,arg6);
    cudaError_t error_gpu = cudaGetLastError();
    if(error_gpu != cudaSuccess)
     { char message[200];
       strcpy(message,"Error kernel call: ");
       strcat(message, cudaGetErrorString(error_gpu));
       enif_raise_exception(env,enif_make_string(env, message, ERL_NIF_LATIN1));
     }
}

__global__
void grad_weights_kernel(float *delta, float *act_prev, float *grad_w, int prev_size, int curr_size)
{
	int tid = ((blockIdx.x * blockDim.x) + threadIdx.x);
if((tid < (prev_size * curr_size)))
{
	int i = (tid / curr_size);
	int j = (tid - (i * curr_size));
	grad_w[tid] = (delta[j] * act_prev[i]);
}

}

extern "C" void grad_weights_kernel_call(ErlNifEnv *env, const ERL_NIF_TERM argv[], ErlNifResourceType* type,ErlNifResourceType* ftype)
  {

    ERL_NIF_TERM list;
    ERL_NIF_TERM head;
    ERL_NIF_TERM tail;

   // void **fun_res;

    const ERL_NIF_TERM *tuple_blocks;
    const ERL_NIF_TERM *tuple_threads;
    int arity;

    if (!enif_get_tuple(env, argv[1], &arity, &tuple_blocks)) {
      printf ("spawn: blocks argument is not a tuple");
    }

    if (!enif_get_tuple(env, argv[2], &arity, &tuple_threads)) {
      printf ("spawn:threads argument is not a tuple");
    }
    int b1,b2,b3,t1,t2,t3;

    enif_get_int(env,tuple_blocks[0],&b1);
    enif_get_int(env,tuple_blocks[1],&b2);
    enif_get_int(env,tuple_blocks[2],&b3);
    enif_get_int(env,tuple_threads[0],&t1);
    enif_get_int(env,tuple_threads[1],&t2);
    enif_get_int(env,tuple_threads[2],&t3);

    dim3 blocks(b1,b2,b3);
    dim3 threads(t1,t2,t3);

    list= argv[3];

  float **array_res1;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res1);
    float *arg1 = *array_res1;
    list = tail;

    float **array_res2;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res2);
    float *arg2 = *array_res2;
    list = tail;

    float **array_res3;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res3);
    float *arg3 = *array_res3;
    list = tail;

    enif_get_list_cell(env,list,&head,&tail);
  int arg4;
  enif_get_int(env, head, &arg4);
  list = tail;

  enif_get_list_cell(env,list,&head,&tail);
  int arg5;
  enif_get_int(env, head, &arg5);
  list = tail;

   grad_weights_kernel<<<blocks, threads>>>(arg1,arg2,arg3,arg4,arg5);
    cudaError_t error_gpu = cudaGetLastError();
    if(error_gpu != cudaSuccess)
     { char message[200];
       strcpy(message,"Error kernel call: ");
       strcat(message, cudaGetErrorString(error_gpu));
       enif_raise_exception(env,enif_make_string(env, message, ERL_NIF_LATIN1));
     }
}

__global__
void sgd_update_kernel(float *params, float *grads, float *updated, float *lr_arr, int size)
{
	int tid = ((blockIdx.x * blockDim.x) + threadIdx.x);
if((tid < size))
{
	updated[tid] = (params[tid] - (lr_arr[0] * grads[tid]));
}

}

extern "C" void sgd_update_kernel_call(ErlNifEnv *env, const ERL_NIF_TERM argv[], ErlNifResourceType* type,ErlNifResourceType* ftype)
  {

    ERL_NIF_TERM list;
    ERL_NIF_TERM head;
    ERL_NIF_TERM tail;

   // void **fun_res;

    const ERL_NIF_TERM *tuple_blocks;
    const ERL_NIF_TERM *tuple_threads;
    int arity;

    if (!enif_get_tuple(env, argv[1], &arity, &tuple_blocks)) {
      printf ("spawn: blocks argument is not a tuple");
    }

    if (!enif_get_tuple(env, argv[2], &arity, &tuple_threads)) {
      printf ("spawn:threads argument is not a tuple");
    }
    int b1,b2,b3,t1,t2,t3;

    enif_get_int(env,tuple_blocks[0],&b1);
    enif_get_int(env,tuple_blocks[1],&b2);
    enif_get_int(env,tuple_blocks[2],&b3);
    enif_get_int(env,tuple_threads[0],&t1);
    enif_get_int(env,tuple_threads[1],&t2);
    enif_get_int(env,tuple_threads[2],&t3);

    dim3 blocks(b1,b2,b3);
    dim3 threads(t1,t2,t3);

    list= argv[3];

  float **array_res1;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res1);
    float *arg1 = *array_res1;
    list = tail;

    float **array_res2;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res2);
    float *arg2 = *array_res2;
    list = tail;

    float **array_res3;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res3);
    float *arg3 = *array_res3;
    list = tail;

    float **array_res4;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res4);
    float *arg4 = *array_res4;
    list = tail;

    enif_get_list_cell(env,list,&head,&tail);
  int arg5;
  enif_get_int(env, head, &arg5);
  list = tail;

   sgd_update_kernel<<<blocks, threads>>>(arg1,arg2,arg3,arg4,arg5);
    cudaError_t error_gpu = cudaGetLastError();
    if(error_gpu != cudaSuccess)
     { char message[200];
       strcpy(message,"Error kernel call: ");
       strcat(message, cudaGetErrorString(error_gpu));
       enif_raise_exception(env,enif_make_string(env, message, ERL_NIF_LATIN1));
     }
}

__global__
void sgd_update_scalar_kernel(float *params, float *grads, float *updated, float lr, int size)
{
	int tid = ((blockIdx.x * blockDim.x) + threadIdx.x);
if((tid < size))
{
	updated[tid] = (params[tid] - (lr * grads[tid]));
}

}

extern "C" void sgd_update_scalar_kernel_call(ErlNifEnv *env, const ERL_NIF_TERM argv[], ErlNifResourceType* type,ErlNifResourceType* ftype)
  {

    ERL_NIF_TERM list;
    ERL_NIF_TERM head;
    ERL_NIF_TERM tail;

   // void **fun_res;

    const ERL_NIF_TERM *tuple_blocks;
    const ERL_NIF_TERM *tuple_threads;
    int arity;

    if (!enif_get_tuple(env, argv[1], &arity, &tuple_blocks)) {
      printf ("spawn: blocks argument is not a tuple");
    }

    if (!enif_get_tuple(env, argv[2], &arity, &tuple_threads)) {
      printf ("spawn:threads argument is not a tuple");
    }
    int b1,b2,b3,t1,t2,t3;

    enif_get_int(env,tuple_blocks[0],&b1);
    enif_get_int(env,tuple_blocks[1],&b2);
    enif_get_int(env,tuple_blocks[2],&b3);
    enif_get_int(env,tuple_threads[0],&t1);
    enif_get_int(env,tuple_threads[1],&t2);
    enif_get_int(env,tuple_threads[2],&t3);

    dim3 blocks(b1,b2,b3);
    dim3 threads(t1,t2,t3);

    list= argv[3];

  float **array_res1;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res1);
    float *arg1 = *array_res1;
    list = tail;

    float **array_res2;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res2);
    float *arg2 = *array_res2;
    list = tail;

    float **array_res3;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res3);
    float *arg3 = *array_res3;
    list = tail;

    enif_get_list_cell(env,list,&head,&tail);
  double darg4;
  float arg4;
  enif_get_double(env, head, &darg4);
  arg4 = (float) darg4;
  list = tail;

  enif_get_list_cell(env,list,&head,&tail);
  int arg5;
  enif_get_int(env, head, &arg5);
  list = tail;

   sgd_update_scalar_kernel<<<blocks, threads>>>(arg1,arg2,arg3,arg4,arg5);
    cudaError_t error_gpu = cudaGetLastError();
    if(error_gpu != cudaSuccess)
     { char message[200];
       strcpy(message,"Error kernel call: ");
       strcat(message, cudaGetErrorString(error_gpu));
       enif_raise_exception(env,enif_make_string(env, message, ERL_NIF_LATIN1));
     }
}

__global__
void zero_kernel(float *buffer, int size)
{
	int tid = ((blockIdx.x * blockDim.x) + threadIdx.x);
if((tid < size))
{
	buffer[tid] = 0.0;
}

}

extern "C" void zero_kernel_call(ErlNifEnv *env, const ERL_NIF_TERM argv[], ErlNifResourceType* type,ErlNifResourceType* ftype)
  {

    ERL_NIF_TERM list;
    ERL_NIF_TERM head;
    ERL_NIF_TERM tail;

   // void **fun_res;

    const ERL_NIF_TERM *tuple_blocks;
    const ERL_NIF_TERM *tuple_threads;
    int arity;

    if (!enif_get_tuple(env, argv[1], &arity, &tuple_blocks)) {
      printf ("spawn: blocks argument is not a tuple");
    }

    if (!enif_get_tuple(env, argv[2], &arity, &tuple_threads)) {
      printf ("spawn:threads argument is not a tuple");
    }
    int b1,b2,b3,t1,t2,t3;

    enif_get_int(env,tuple_blocks[0],&b1);
    enif_get_int(env,tuple_blocks[1],&b2);
    enif_get_int(env,tuple_blocks[2],&b3);
    enif_get_int(env,tuple_threads[0],&t1);
    enif_get_int(env,tuple_threads[1],&t2);
    enif_get_int(env,tuple_threads[2],&t3);

    dim3 blocks(b1,b2,b3);
    dim3 threads(t1,t2,t3);

    list= argv[3];

  float **array_res1;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res1);
    float *arg1 = *array_res1;
    list = tail;

    enif_get_list_cell(env,list,&head,&tail);
  int arg2;
  enif_get_int(env, head, &arg2);
  list = tail;

   zero_kernel<<<blocks, threads>>>(arg1,arg2);
    cudaError_t error_gpu = cudaGetLastError();
    if(error_gpu != cudaSuccess)
     { char message[200];
       strcpy(message,"Error kernel call: ");
       strcat(message, cudaGetErrorString(error_gpu));
       enif_raise_exception(env,enif_make_string(env, message, ERL_NIF_LATIN1));
     }
}

__global__
void apply_mean_update_kernel(float *params, float *grads, float lr, int batch_count, int size)
{
	int tid = ((blockIdx.x * blockDim.x) + threadIdx.x);
if((tid < size))
{
	params[tid] = (params[tid] - ((lr / batch_count) * grads[tid]));
}

}

extern "C" void apply_mean_update_kernel_call(ErlNifEnv *env, const ERL_NIF_TERM argv[], ErlNifResourceType* type,ErlNifResourceType* ftype)
  {

    ERL_NIF_TERM list;
    ERL_NIF_TERM head;
    ERL_NIF_TERM tail;

   // void **fun_res;

    const ERL_NIF_TERM *tuple_blocks;
    const ERL_NIF_TERM *tuple_threads;
    int arity;

    if (!enif_get_tuple(env, argv[1], &arity, &tuple_blocks)) {
      printf ("spawn: blocks argument is not a tuple");
    }

    if (!enif_get_tuple(env, argv[2], &arity, &tuple_threads)) {
      printf ("spawn:threads argument is not a tuple");
    }
    int b1,b2,b3,t1,t2,t3;

    enif_get_int(env,tuple_blocks[0],&b1);
    enif_get_int(env,tuple_blocks[1],&b2);
    enif_get_int(env,tuple_blocks[2],&b3);
    enif_get_int(env,tuple_threads[0],&t1);
    enif_get_int(env,tuple_threads[1],&t2);
    enif_get_int(env,tuple_threads[2],&t3);

    dim3 blocks(b1,b2,b3);
    dim3 threads(t1,t2,t3);

    list= argv[3];

  float **array_res1;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res1);
    float *arg1 = *array_res1;
    list = tail;

    float **array_res2;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res2);
    float *arg2 = *array_res2;
    list = tail;

    enif_get_list_cell(env,list,&head,&tail);
  double darg3;
  float arg3;
  enif_get_double(env, head, &darg3);
  arg3 = (float) darg3;
  list = tail;

  enif_get_list_cell(env,list,&head,&tail);
  int arg4;
  enif_get_int(env, head, &arg4);
  list = tail;

  enif_get_list_cell(env,list,&head,&tail);
  int arg5;
  enif_get_int(env, head, &arg5);
  list = tail;

   apply_mean_update_kernel<<<blocks, threads>>>(arg1,arg2,arg3,arg4,arg5);
    cudaError_t error_gpu = cudaGetLastError();
    if(error_gpu != cudaSuccess)
     { char message[200];
       strcpy(message,"Error kernel call: ");
       strcat(message, cudaGetErrorString(error_gpu));
       enif_raise_exception(env,enif_make_string(env, message, ERL_NIF_LATIN1));
     }
}

__global__
void train_batch_kernel(float *weights, float *biases, float *train_x, float *train_y, float *grad_w, float *grad_b, int *layers, int *weight_offsets, int *bias_offsets, int *neuron_offsets, int layer_count, int input_size, int train_count, int total_neurons)
{
	int tid = ((blockIdx.x * blockDim.x) + threadIdx.x);
float act[512];
float delta[512];
if((tid < train_count))
{
for( int i = 0; i<input_size; i+=1){
	act[i] = train_x[((tid * input_size) + i)];
}

for( int l = 1; l<layer_count; l+=1){
	int prev_size = layers[(l - 1)];
	int curr_size = layers[l];
	int w_off = weight_offsets[l];
	int b_off = bias_offsets[l];
	int prev_off = neuron_offsets[(l - 1)];
	int curr_off = neuron_offsets[l];
	int is_output = (l == (layer_count - 1));
for( int j = 0; j<curr_size; j+=1){
	float net = biases[(b_off + j)];
for( int i = 0; i<prev_size; i+=1){
	net = (net + (weights[((w_off + (i * curr_size)) + j)] * act[(prev_off + i)]));
}

if(is_output)
{
	act[(curr_off + j)] = sigmoid(net);
}
else{
	act[(curr_off + j)] = relu(net);
}

}

}

	int out_l = (layer_count - 1);
	int out_size = layers[out_l];
	int out_off = neuron_offsets[out_l];
	float y = train_y[tid];
for( int j = 0; j<out_size; j+=1){
	delta[(out_off + j)] = (act[(out_off + j)] - y);
}

for( int rev = 1; rev<(layer_count - 1); rev+=1){
	int hl = ((layer_count - 1) - rev);
	int h_curr_size = layers[hl];
	int h_next_size = layers[(hl + 1)];
	int h_curr_off = neuron_offsets[hl];
	int h_next_off = neuron_offsets[(hl + 1)];
	int h_w_next_off = weight_offsets[(hl + 1)];
for( int j = 0; j<h_curr_size; j+=1){
	float sum = 0.0;
for( int k = 0; k<h_next_size; k+=1){
	sum = (sum + (weights[((h_w_next_off + (j * h_next_size)) + k)] * delta[(h_next_off + k)]));
}

if((act[(h_curr_off + j)] > 0.0))
{
	delta[(h_curr_off + j)] = sum;
}
else{
	delta[(h_curr_off + j)] = 0.0;
}

}

}

for( int gl = 1; gl<layer_count; gl+=1){
	int g_prev_size = layers[(gl - 1)];
	int g_curr_size = layers[gl];
	int g_prev_off = neuron_offsets[(gl - 1)];
	int g_curr_off = neuron_offsets[gl];
	int g_w_off = weight_offsets[gl];
	int g_b_off = bias_offsets[gl];
for( int j = 0; j<g_curr_size; j+=1){
	float d = delta[(g_curr_off + j)];
atomicAdd(((grad_b + g_b_off) + j), d);
for( int i = 0; i<g_prev_size; i+=1){
atomicAdd((((grad_w + g_w_off) + (i * g_curr_size)) + j), (d * act[(g_prev_off + i)]));
}

}

}

}

}

extern "C" void train_batch_kernel_call(ErlNifEnv *env, const ERL_NIF_TERM argv[], ErlNifResourceType* type,ErlNifResourceType* ftype)
  {

    ERL_NIF_TERM list;
    ERL_NIF_TERM head;
    ERL_NIF_TERM tail;

   // void **fun_res;

    const ERL_NIF_TERM *tuple_blocks;
    const ERL_NIF_TERM *tuple_threads;
    int arity;

    if (!enif_get_tuple(env, argv[1], &arity, &tuple_blocks)) {
      printf ("spawn: blocks argument is not a tuple");
    }

    if (!enif_get_tuple(env, argv[2], &arity, &tuple_threads)) {
      printf ("spawn:threads argument is not a tuple");
    }
    int b1,b2,b3,t1,t2,t3;

    enif_get_int(env,tuple_blocks[0],&b1);
    enif_get_int(env,tuple_blocks[1],&b2);
    enif_get_int(env,tuple_blocks[2],&b3);
    enif_get_int(env,tuple_threads[0],&t1);
    enif_get_int(env,tuple_threads[1],&t2);
    enif_get_int(env,tuple_threads[2],&t3);

    dim3 blocks(b1,b2,b3);
    dim3 threads(t1,t2,t3);

    list= argv[3];

  float **array_res1;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res1);
    float *arg1 = *array_res1;
    list = tail;

    float **array_res2;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res2);
    float *arg2 = *array_res2;
    list = tail;

    float **array_res3;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res3);
    float *arg3 = *array_res3;
    list = tail;

    float **array_res4;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res4);
    float *arg4 = *array_res4;
    list = tail;

    float **array_res5;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res5);
    float *arg5 = *array_res5;
    list = tail;

    float **array_res6;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res6);
    float *arg6 = *array_res6;
    list = tail;

    int **array_res7;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res7);
    int *arg7 = *array_res7;
    list = tail;

    int **array_res8;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res8);
    int *arg8 = *array_res8;
    list = tail;

    int **array_res9;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res9);
    int *arg9 = *array_res9;
    list = tail;

    int **array_res10;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res10);
    int *arg10 = *array_res10;
    list = tail;

    enif_get_list_cell(env,list,&head,&tail);
  int arg11;
  enif_get_int(env, head, &arg11);
  list = tail;

  enif_get_list_cell(env,list,&head,&tail);
  int arg12;
  enif_get_int(env, head, &arg12);
  list = tail;

  enif_get_list_cell(env,list,&head,&tail);
  int arg13;
  enif_get_int(env, head, &arg13);
  list = tail;

  enif_get_list_cell(env,list,&head,&tail);
  int arg14;
  enif_get_int(env, head, &arg14);
  list = tail;

   train_batch_kernel<<<blocks, threads>>>(arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13,arg14);
    cudaError_t error_gpu = cudaGetLastError();
    if(error_gpu != cudaSuccess)
     { char message[200];
       strcpy(message,"Error kernel call: ");
       strcat(message, cudaGetErrorString(error_gpu));
       enif_raise_exception(env,enif_make_string(env, message, ERL_NIF_LATIN1));
     }
}

__global__
void predict_batch_kernel(float *weights, float *biases, float *batch_x, float *output, int *layers, int *weight_offsets, int *bias_offsets, int *neuron_offsets, int layer_count, int input_size, int batch_count, int total_neurons)
{
	int tid = ((blockIdx.x * blockDim.x) + threadIdx.x);
float act[512];
if((tid < batch_count))
{
for( int i = 0; i<input_size; i+=1){
	act[i] = batch_x[((tid * input_size) + i)];
}

for( int l = 1; l<layer_count; l+=1){
	int prev_size = layers[(l - 1)];
	int curr_size = layers[l];
	int w_off = weight_offsets[l];
	int b_off = bias_offsets[l];
	int prev_off = neuron_offsets[(l - 1)];
	int curr_off = neuron_offsets[l];
	int is_output = (l == (layer_count - 1));
for( int j = 0; j<curr_size; j+=1){
	float net = biases[(b_off + j)];
for( int i = 0; i<prev_size; i+=1){
	net = (net + (weights[((w_off + (i * curr_size)) + j)] * act[(prev_off + i)]));
}

if(is_output)
{
	act[(curr_off + j)] = sigmoid(net);
}
else{
	act[(curr_off + j)] = relu(net);
}

}

}

	int out_l = (layer_count - 1);
	int out_off = neuron_offsets[out_l];
	output[tid] = act[out_off];
}

}

extern "C" void predict_batch_kernel_call(ErlNifEnv *env, const ERL_NIF_TERM argv[], ErlNifResourceType* type,ErlNifResourceType* ftype)
  {

    ERL_NIF_TERM list;
    ERL_NIF_TERM head;
    ERL_NIF_TERM tail;

   // void **fun_res;

    const ERL_NIF_TERM *tuple_blocks;
    const ERL_NIF_TERM *tuple_threads;
    int arity;

    if (!enif_get_tuple(env, argv[1], &arity, &tuple_blocks)) {
      printf ("spawn: blocks argument is not a tuple");
    }

    if (!enif_get_tuple(env, argv[2], &arity, &tuple_threads)) {
      printf ("spawn:threads argument is not a tuple");
    }
    int b1,b2,b3,t1,t2,t3;

    enif_get_int(env,tuple_blocks[0],&b1);
    enif_get_int(env,tuple_blocks[1],&b2);
    enif_get_int(env,tuple_blocks[2],&b3);
    enif_get_int(env,tuple_threads[0],&t1);
    enif_get_int(env,tuple_threads[1],&t2);
    enif_get_int(env,tuple_threads[2],&t3);

    dim3 blocks(b1,b2,b3);
    dim3 threads(t1,t2,t3);

    list= argv[3];

  float **array_res1;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res1);
    float *arg1 = *array_res1;
    list = tail;

    float **array_res2;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res2);
    float *arg2 = *array_res2;
    list = tail;

    float **array_res3;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res3);
    float *arg3 = *array_res3;
    list = tail;

    float **array_res4;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res4);
    float *arg4 = *array_res4;
    list = tail;

    int **array_res5;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res5);
    int *arg5 = *array_res5;
    list = tail;

    int **array_res6;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res6);
    int *arg6 = *array_res6;
    list = tail;

    int **array_res7;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res7);
    int *arg7 = *array_res7;
    list = tail;

    int **array_res8;
    enif_get_list_cell(env,list,&head,&tail);
    enif_get_resource(env, head, type, (void **) &array_res8);
    int *arg8 = *array_res8;
    list = tail;

    enif_get_list_cell(env,list,&head,&tail);
  int arg9;
  enif_get_int(env, head, &arg9);
  list = tail;

  enif_get_list_cell(env,list,&head,&tail);
  int arg10;
  enif_get_int(env, head, &arg10);
  list = tail;

  enif_get_list_cell(env,list,&head,&tail);
  int arg11;
  enif_get_int(env, head, &arg11);
  list = tail;

  enif_get_list_cell(env,list,&head,&tail);
  int arg12;
  enif_get_int(env, head, &arg12);
  list = tail;

   predict_batch_kernel<<<blocks, threads>>>(arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12);
    cudaError_t error_gpu = cudaGetLastError();
    if(error_gpu != cudaSuccess)
     { char message[200];
       strcpy(message,"Error kernel call: ");
       strcat(message, cudaGetErrorString(error_gpu));
       enif_raise_exception(env,enif_make_string(env, message, ERL_NIF_LATIN1));
     }
}
