#pragma once
#include <vector>

const int MAX_LAYER = 8;

struct MLPLayer
{
    int m_LayerCount;
    int m_Layers[MAX_LAYER];

    // Mapeamento de (camada, neurônio): O(1) dentro dos kernels.
    int m_NeuronOffset[MAX_LAYER];
    int m_WeightOffset[MAX_LAYER];
    int m_BiasOffset[MAX_LAYER];

    int m_TotalNeurons;
    int m_TotalWeights;
    int m_TotalBiases;

    float* m_Weights;
    float* m_Biases;
};

class MLPClassifierNIF
{
public:
    MLPClassifierNIF(const std::vector<int>& layers,
                     const std::vector<float>& flatWeights,
                     const std::vector<float>& flatBiases);
    ~MLPClassifierNIF();

    bool TrainBatch(float* trainx, float* trainy, int batchCount, float learnRate);
    float* Predict(float* testx, int testCount);
    void GetLastTimings(long long* cpuToGpuUs, long long* gpuComputeUs, long long* gpuToCpuUs) const;

private:
    bool EnsureBatchCapacity(int batchCount);

    bool m_Initialized;
    bool m_DebugInitialSnapshotPrinted;
    int  m_DebugBatchCalls;
    int  m_BatchCapacity;

    MLPLayer m_MLPLayer;

    float* m_cuWeights;
    float* m_cuBiases;
    float* m_cuGradW;
    float* m_cuGradB;
    float* m_cuBatchX;
    float* m_cuBatchY;
    float* m_cuResults;

    long long m_LastCpuToGpuUs;
    long long m_LastGpuComputeUs;
    long long m_LastGpuToCpuUs;
};
